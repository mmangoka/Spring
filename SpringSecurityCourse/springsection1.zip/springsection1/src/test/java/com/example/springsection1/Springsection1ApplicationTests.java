package com.example.springsection1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsection1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
